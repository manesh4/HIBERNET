package com.relationship;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class AppMain {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		Address ad = new Address();
		ad.setId(101);
		ad.setAddress("Odisa");
		
		EmpDetails e = new EmpDetails();
		e.setId(201);
		e.setName("Ajay");
		e.setAddress(ad);
		
		ad.setEmp(e);
		
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
//		session.save(ad);
//		session.save(e);
		
		EmpDetails emp=(EmpDetails)session.get(EmpDetails.class, 201);
		System.out.println(emp.getName());
		System.out.println(emp.getAddress().getAddress());
		
//		Address na = (Address)session.get(Address.class, 101);
//		System.out.println(na.getAddress());
//		System.out.println(na.getEmp().getName());
		
		tx.commit();
		session.close();
		
//		System.out.println("Data Inserted Successfully");
//		System.out.println(factory);
		factory.close();
	}

}
