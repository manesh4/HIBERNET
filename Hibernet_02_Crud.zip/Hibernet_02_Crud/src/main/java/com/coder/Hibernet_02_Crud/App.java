package com.coder.Hibernet_02_Crud;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory factory = HibernateUtil.getSessionFactory();
    	
    	Session session = factory.openSession();
    	
    	//Create
    	
//    	Student st = new Student();
//    	st.setName("Jay");
//    	st.setAddress("India");
//    	st.setEmail("jay@123gmail.com");
//    	st.setCollegeName("India University");
//    	
//    	Student st2 = new Student();
//    	st2.setName("Vijay");
//    	st2.setAddress("UK");
//    	st2.setEmail("Vijjay@123gmail.com");
//    	st2.setCollegeName("UK University");
//    	
//    	
//    	Transaction tx = session.beginTransaction();
//    	
//    	session.save(st);
//    	session.save(st2);
//    	
//    	tx.commit();
//    	System.out.println("Student Registerd Successfully");
    	
    	
    	//Read
    	
//    	List<Student> list = session.createQuery("from Student",Student.class).list();
//    	list.forEach(e -> System.out.println(e));
    	
    	//Get By Id
    	
//    	Student st = session.get(Student.class,1);
//    	System.out.println(st);
    	
    	
    	//Update
    	
//    	Student st = session.get(Student.class,1);
//    	st.setName("Raj");
//    	st.setAddress("Canada");
//    	st.setEmail("raj@gmail.com");
//    	st.setCollegeName("Canada University");
//    	Transaction tx = session.beginTransaction();
//    	
//    	session.saveOrUpdate(st);
//    	tx.commit();
//    	System.out.println("Data Updated Successfully");
    	
    	
    	//Delete
    	
//    	Student st = session.get(Student.class,1);
//    	Transaction tx = session.beginTransaction();
//    	session.delete(st);
//    	tx.commit();
//    	System.out.println("Data Deleted Successfully");
//    	
//    	session.close();
//    	factory.close();
    }
}
