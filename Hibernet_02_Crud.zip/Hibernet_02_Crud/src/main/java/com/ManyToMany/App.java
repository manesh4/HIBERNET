package com.ManyToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class App {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
//		System.out.println(sessionFactory);
		
		Emp e1 = new Emp();
		e1.setId(101);
		e1.setName("Prem");
		
		Emp e2 = new Emp();
		e2.setId(2);
		e2.setName("Nikita");
		
		Address a1 = new Address();
		a1.setId(201);
		a1.setAddressName("Kolhapur");
		
		Address a2 = new Address();
		a2.setId(202);
		a2.setAddressName("Pune");
		
		List<Address> addList = new ArrayList<Address>();
		addList.add(a1);
		addList.add(a2);
		
		List<Emp> empList = new ArrayList<Emp>();
		empList.add(e1);
		empList.add(e2);
		
		e1.setAddress(addList);
		a1.setEmp(empList);
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
//		session.save(e1);
//		session.save(e2);
//		session.save(a1);
//		session.save(a2);
//		
//		System.out.println("Registered Successfully");
		
		Emp emp = (Emp)session.get(Emp.class, 101);	
		System.out.println(emp.getName());
		System.out.println(emp.getAddress().size());
		
		tx.commit();
		session.close();
	
		
		sessionFactory.close();

	}

}
