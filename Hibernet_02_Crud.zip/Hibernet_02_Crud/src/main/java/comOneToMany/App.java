package comOneToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class App {

	public static void main(String args[])
	{
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		Address ad1 = new Address(101,"Permanent Address","Bombay");
		Address ad2 = new Address(102,"Office Address","Canada");
		
		List<Address> list = new ArrayList<Address>();
		list.add(ad1);
		list.add(ad2);
		
		EmpDetails emp = new EmpDetails();
		emp.setId(202);
		emp.setName("Radhe Mohan");
		emp.setAddress(list);

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(emp);
		session.save(ad1);
		session.save(ad2);
//	
//		session.save(emp);
//		
//		System.out.println("Data Inserted Successfully");
		
		
		EmpDetails em = (EmpDetails)session.get(EmpDetails.class, 201);
		System.out.println("Emp Name = "+em.getName());
		
		for(Address ad : em.getAddress()) {
			System.out.println("Address type = "+ad.getAddressType()+", address = "+ad.getAddress());
		}
		
//		Address ad = (Address) session.get(Address.class, 101);
//		System.out.println("Emp Name = "+ad.getClass().getName());
//		System.out.println(ad.getAddressType()+" , "+ad.getAddress());
		
		tx.commit();
		session.close();
		factory.close();
	}
}
