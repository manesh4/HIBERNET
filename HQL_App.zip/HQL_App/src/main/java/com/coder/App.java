package com.coder;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory factory = HibernateUtil.getSessionFactory();
        System.out.println( factory);
        
        
        
        Student st = new Student();
        st.setName("coder");
        st.setAddress("Pune");
        
        Student st2 = new Student();
        st2.setName("amit");
        st2.setAddress("kolhapur");
        
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        
//        session.save(st);
//        session.save(st2);
//        tx.commit();
        
//        Query q = session.createQuery("from Student");
//        List<Student> list = q.list();
//        
//        for(Student s:list)
//        {
//        	System.out.println(s);
//        }
        
        System.out.println(session.get(Student.class,1));
        
        
//        Query q = session.createQuery("from Student where id = '1' and address = 'Pune'" );
//        System.out.println(q.uniqueResult());
        
//        Query q = session.createQuery("from Student where id =:id and address =:ad" );
//        q.setParameter("id", 2);
//        q.setParameter("ad", "kolhapur");
//        System.out.println(q.uniqueResult());
        
//      Query q = session.createQuery("delete from Student where id ='1'");
//     	int i = q.executeUpdate();
//      System.out.println(i+"update successfully");
        
        
//        System.out.println("register successfully");
        
        session.close();
        factory.close();
    }
}
