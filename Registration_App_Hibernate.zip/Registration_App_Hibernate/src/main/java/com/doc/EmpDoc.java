package com.doc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.entity.Emp;

public class EmpDoc {
	
	private SessionFactory sessionFactory;

	public EmpDoc(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	public boolean saveEmp(Emp emp)
	{
		boolean f = false;
		
		Session session = sessionFactory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		int i = (Integer)session.save(emp);
		
		if(i>0)
		{
			f=true;
		}
		
		tx.commit();
		session.close();
		
		return f;
	}

}
